import { Profesorado } from './Profesorado.js';

export class Modulo {
    constructor(nombre, horas, profesores) {
        this.nombre = nombre;
        this.horas = horas;
        this.profesores = profesores;
    }


}